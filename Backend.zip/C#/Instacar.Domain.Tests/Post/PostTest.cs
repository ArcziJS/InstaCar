﻿using System;
using Instacar.Common.Enums;
using Instacar.Domain.DomainExceptions;
using Xunit;

namespace Instacar.Domain.Tests.Post
{
    public class PostTest
    {
        public PostTest()
        {
            //Arrange
            //Act
            //Assert
        }

        [Fact]
        public void CreatePost_Returns_Correct_Response()
        {
            var Post = new Domain.Post.Post(1, "Opis", DateTime.UtcNow, DateTime.UtcNow);

            Assert.Equal("Opis", Post.PostDescription);
            // Assert.Equal(DateTime.UtcNow, Post.CreationDate);
            //Assert.Equal(DateTime.UtcNow, Post.EditionDate);
        }

    }
}