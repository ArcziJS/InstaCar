﻿using System.Threading.Tasks;
using Instacar.IData.Post;
using Google.Protobuf.WellKnownTypes;
using Microsoft.EntityFrameworkCore;

namespace Instacar.Data.Sql.Post
{
    public class PostRepository : IPostRepository
    {
        private readonly InstacarDbContext _context;

        public PostRepository(InstacarDbContext context)
        {
            _context = context;
        }

        public async Task<int> AddPost(Domain.Post.Post Post)
        {
            var PostDAO = new DAO.Post
            {
                PostId = Post.PostId,
                UserId = Post.UserId,
                PostDescription = Post.PostDescription,
                CreationDate = Post.CreationDate,
                EditionDate = Post.EditionDate,
                IsActivePost = Post.IsActivePost,
                IsBannedPost = Post.IsBannedPost,
                LikesCount = Post.LikesCount,
                CommentsCount = Post.CommentsCount,
            };
            await _context.AddAsync(PostDAO);
            await _context.SaveChangesAsync();
            return PostDAO.PostId;
        }

        public async Task<Domain.Post.Post> GetPost(int PostId)
        {
            var Post = await _context.Post.FirstOrDefaultAsync(x => x.PostId == PostId);
            return new Domain.Post.Post(
                Post.PostId,
                Post.UserId,
                Post.PostDescription,
                Post.CreationDate,
                Post.EditionDate,
                Post.LikesCount,
                Post.CommentsCount,
                Post.IsBannedPost,
                Post.IsActivePost);
        }
        

        public async Task EditPost(Domain.Post.Post Post)
        {
            var editPost = await _context.Post.FirstOrDefaultAsync(x => x.PostId == Post.PostId);
            editPost.PostId = Post.PostId;
            editPost.PostDescription = Post.PostDescription;
            editPost.EditionDate = Post.EditionDate;
            await _context.SaveChangesAsync();
        }

        public async Task DeletePost(Domain.Post.Post Post)
        {
            var deletePost = await _context.Post.FirstOrDefaultAsync(x => x.PostId == Post.PostId);
            _context.Remove(deletePost.PostId);
            await _context.SaveChangesAsync();
        }
    }

}