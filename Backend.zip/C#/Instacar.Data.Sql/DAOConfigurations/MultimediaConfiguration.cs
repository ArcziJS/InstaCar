using Instacar.Data.Sql.DAO;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Instacar.Data.Sql.DAOConfigurations
{
    public class MediaConfiguration: IEntityTypeConfiguration<Multimedia>
    {
        public void Configure(EntityTypeBuilder<Multimedia> builder)
        {
            builder.Property(c => c.MultimediaHref).IsRequired(); 
            builder.HasOne(x => x.Post)
                .WithMany(x => x.Multimedias)
                .OnDelete(DeleteBehavior.Restrict)
                .HasForeignKey(x => x.PostId);
            builder.ToTable("Media");
        }
    }
}