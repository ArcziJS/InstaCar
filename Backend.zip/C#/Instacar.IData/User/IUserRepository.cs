﻿using System.Threading.Tasks;

namespace Instacar.IData.User
{
    public interface IUserRepository
    {
        Task<int> AddUser(Instacar.Domain.User.User addUser);
        Task<Instacar.Domain.User.User> GetUser(int userId);
        Task<Instacar.Domain.User.User> GetUser(string userName);
        Task EditUser(Instacar.Domain.User.User editUser);
    }
}