﻿using System;
using System.Threading.Tasks;
using Instacar.Common.Enums;
using Instacar.Data.Sql.User;
using Instacar.IData.User;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace Instacar.Data.Sql.Tests.User
{
    public class UserRepositoryTest
    {
        public IConfiguration Configuration { get; }
        private InstacarDbContext _context;
        private IUserRepository _userRepository;

        public UserRepositoryTest()
        {
            var optionsBuilder = new DbContextOptionsBuilder<InstacarDbContext>();
            optionsBuilder.UseMySQL(
                "server=localhost;userid=root;pwd=ZAQ!2wsx;port=3306;database=Instacar_db;");
            _context = new InstacarDbContext(optionsBuilder.Options);
            _context.Database.EnsureDeleted();
            _context.Database.EnsureCreated();
            _userRepository = new UserRepository(_context);
        }

        [Fact]
        public async Task AddUser_Returns_Correct_Response()
        {
            var user = new Domain.User.User("Name", "Email", Gender.Male, DateTime.UtcNow);

            var userId = await _userRepository.AddUser(user);

            var createdUser = await _context.User.FirstOrDefaultAsync(x => x.UserId == userId);
            Assert.NotNull(createdUser);

            _context.User.Remove(createdUser);
            await _context.SaveChangesAsync();
            _context.Database.EnsureDeleted();
        }

    }
}