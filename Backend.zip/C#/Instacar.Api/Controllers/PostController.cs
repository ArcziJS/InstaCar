﻿using System;
using System.Threading.Tasks;
using Instacar.Api.BindingModels;
using Instacar.Api.Validation;
using Instacar.Api.ViewModels;
using Instacar.Data.Sql;
using Instacar.Data.Sql.DAO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Instacar.Api.Controllers
{
	[ApiVersion("1.0")]
	[Route("api/v{version:apiVersion}/[controller]")]
	public class PostController : Controller
	{
		private readonly InstacarDbContext _context;
		public PostController(InstacarDbContext context)
		{
			_context = context;
		}


		[ValidateModel]
		//[Consumes("application/x-www-form-urlencoded")]
		[HttpPost("create", Name = "CreatePost")]
		public async Task<IActionResult> Post([FromBody] CreatePost createPost)
		{
			var post = new Post
			{
				PostDescription = createPost.PostDescription,
				UserId = 1,
				CreationDate = DateTime.UtcNow,
				EditionDate = DateTime.UtcNow,
				IsActivePost = true,
				IsBannedPost = false
			};
			await _context.AddAsync(post);
			await _context.SaveChangesAsync();

			return Created(post.PostId.ToString(), new PostViewModel
			{
				PostId = post.PostId,
				UserId = post.UserId,
				PostDescription = post.PostDescription,
				CreationDate = post.CreationDate,
				EditionDate = post.EditionDate,
				LikesCount = post.LikesCount,
				CommentsCount = post.CommentsCount,
				IsBannedPost = post.IsBannedPost,
				IsActivePost = post.IsActivePost
			}) ;
		}

		[ValidateModel]
		[HttpPatch("edit/{postId:min(1)}", Name = "EditPost")]
		// public async Task<IActionResult> Editpost([FromBody] Editpost editpost,[FromQuery] int postId)
		public async Task<IActionResult> EditPost([FromBody] EditPost editPost, int postId)
		{

			var post = await _context.Post.FirstOrDefaultAsync(x => x.PostId == postId);
			post.PostDescription = editPost.PostDescription;
			post.EditionDate = DateTime.UtcNow;
			post.LikesCount = editPost.LikesCount;
			await _context.SaveChangesAsync();
			return Ok(new PostViewModel
			{
				PostId = post.PostId,
				UserId = post.UserId,
				PostDescription = post.PostDescription,
				CreationDate=post.CreationDate,
				EditionDate= post.CreationDate,
				LikesCount= post.LikesCount,
				CommentsCount= post.CommentsCount,
				IsBannedPost=post.IsBannedPost,
				IsActivePost=post.IsActivePost
			}) ;
		}

		[HttpDelete("delete/{postId:min(1)}", Name = "DeletePost")]
		public async Task<IActionResult> DeletePostById(int postId)
		{
			var post = await _context.Post.FindAsync(postId);

			if (post != null)
			{
				_context.Post.Remove(post);
				await _context.SaveChangesAsync();
			}
			return NoContent();
		}

		[HttpGet("{postId:min(1)}", Name = "GetPostById")]
		public async Task<IActionResult> GetPostById(int postId)
		{
			var post = await _context.Post.FirstOrDefaultAsync(x => x.PostId == postId);

			if (post != null)
			{
				return Ok(new PostViewModel
				{
					PostId = post.PostId,
					UserId = post.UserId,
					PostDescription = post.PostDescription,
					CreationDate = post.CreationDate,
					EditionDate = post.CreationDate,
					LikesCount = post.LikesCount,
					CommentsCount = post.CommentsCount,
					IsBannedPost = post.IsBannedPost,
					IsActivePost = post.IsActivePost
				});
			}
			return Ok();
		}
	}
}
