﻿using System;

namespace Instacar.Api.ViewModels
{
    public class PostViewModel
    {
        public int PostId { get; set; }
        public int UserId { get; set; }
        public string PostDescription { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime EditionDate { get; set; }
        public int LikesCount { get; set; }
        public int CommentsCount { get; set; }
        public bool IsBannedPost { get; set; }
        public bool IsActivePost { get; set; }
    }
}
