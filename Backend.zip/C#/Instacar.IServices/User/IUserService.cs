﻿using System.Threading.Tasks;
using Instacar.IServices.Requests;

namespace Instacar.IServices.User
{
    public interface IUserService
    {
        Task<Instacar.Domain.User.User> GetUserByUserId(int userId);
        Task<Instacar.Domain.User.User> GetUserByUserName(string userName);
        Task<Instacar.Domain.User.User> CreateUser(CreateUser createUser);
        Task EditUser(EditUser editUser, int userId);
    }
}