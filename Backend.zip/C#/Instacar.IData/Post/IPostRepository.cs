﻿using System.Threading.Tasks;

namespace Instacar.IData.Post
{
    public interface IPostRepository
    {
        Task<int> AddPost(Instacar.Domain.Post.Post addPost);
        Task<Instacar.Domain.Post.Post> GetPost(int PostId);
        Task EditPost(Instacar.Domain.Post.Post editPost);
        Task DeletePost(Instacar.Domain.Post.Post deletePost);
    }
}