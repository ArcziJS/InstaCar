﻿using System;
using System.ComponentModel.DataAnnotations;
//using FluentValidation;

namespace Instacar.IServices.Requests
{
    public class EditPost
    {
        [Required]
        [Display(Name = "PostId")]
        public int PostId { get; set; }
        [Required]
        [Display(Name = "PostDescription")]
        public string PostDescription { get; set; }

        [Required]
        [Display(Name = "EditionDate")]
        public DateTime EditionDate { get; set; }
    }

    //public class EditPostValidator : AbstractValidator<EditPost>
    //{
    //    public EditPostValidator()
    //    {
    //        RuleFor(x => x.PostDescription).NotNull();
    //    }
    //}
}
