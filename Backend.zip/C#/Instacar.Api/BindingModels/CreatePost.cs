﻿using System;
using System.ComponentModel.DataAnnotations;
using Instacar.Common.Enums;
using Instacar.Data.Sql.DAO;
using FluentValidation;

namespace Instacar.Api.BindingModels
{
    public class CreatePost
    {
        [Required]
        [Display(Name = "UserId")]
        public int UserId { get; set; }

        [Required]
        [Display(Name = "PostDescription")]
        public string PostDescription { get; set; }

        [Required]
        [Display(Name = "CreationDate")]
        public DateTime CreationDate { get; set; }

        [Required]
        [Display(Name = "EditionDate")]
        public DateTime EditionDate { get; set; }

    }
}
