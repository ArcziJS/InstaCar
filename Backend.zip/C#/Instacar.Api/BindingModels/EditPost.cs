﻿using System;
using System.ComponentModel.DataAnnotations;
using FluentValidation;

namespace Instacar.Api.BindingModels
{
    public class EditPost
    {
        [Required]
        [Display(Name = "PostDescription")]
        public string PostDescription { get; set; }

        [Required]
        [Display(Name = "EditionDate")]
        public DateTime EditionDate { get; set; }

        [Display(Name = "LikesCount")]
        public int LikesCount { get; set; }
    }

    public class EditPostValidator : AbstractValidator<EditPost>
    {
        public EditPostValidator()
        {
            RuleFor(x => x.PostDescription).NotNull();
        }
    }
}
