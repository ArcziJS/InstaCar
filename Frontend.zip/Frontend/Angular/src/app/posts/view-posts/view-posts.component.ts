import { Component, OnInit } from '@angular/core';
import { Post } from '../../post.model'
import { SharedService } from 'src/app/shared.service';
import { response } from 'express';
import { User } from '../../user.model'


@Component({
  selector: 'app-view-posts',
  templateUrl: './view-posts.component.html',
  styleUrls: ['./view-posts.component.css']
})
export class ViewPostsComponent implements OnInit {

  constructor(public service: SharedService) { }
  post:Post = new Post();
  Posts: Array<Post>=[];
  poka=true;
  logowanie=false;
  user:User=new User();
  Users: Array<User>=[];

ngOnInit() 
{
  for (var i=1;i<51;i++)
  {
    this.service.GetPost(i).subscribe(response => {
      this.post = response;
      console.log(this.post)
      this.Posts.push(this.post)
    });
    
  }
  }

  UpdatePost(id: number, post:Post)
  {
    this.service.UpdatePost(id,post)
    .subscribe(response=>
      {
        console.log(response)
      })
      alert('Udało się.');
  }

  DeletePost(id: number)
  {
    this.service.DeletePost(id).subscribe(response=>
      {
          alert('Usunięto post.')
      })
  }

  DajLajka(id:number, polubiony:Post)
  {
    polubiony.likesCount++;
    console.log(polubiony);
    this.service.UpdatePost(id,polubiony).subscribe(response => {
      console.log(response)});
      alert("Polubiono.")
  }

  GetUserName(id:number)
  {
    this.service.GetUser(id).subscribe(response=>
      {
        this.user=response;
        console.log(this.user);
      })
  }

  
  

}
