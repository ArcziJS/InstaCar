import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Response } from 'express';
import { Post } from './post.model';
import { User } from './user.model';

const APIUrl = 'https://localhost:44386/api/v1';

@Injectable
({
  providedIn: 'root'
})
export class SharedService
{
  constructor(private http: HttpClient) 
  {
    
  }

  post:Post = new Post();
  user:User = new User();

  GetUser(id: number):Observable<User>
  {
    return this.http.get<User>(`${APIUrl}/user/${id}`);
  }

  GetUserName(name: string):Observable<User>
  {
    return this.http.get<User>(`${APIUrl}/user/name/${name}`);
  }

  GetPost(id: number):Observable<Post>
  {
    return this.http.get<Post>(`${APIUrl}/post/${id}`);
  }

  AddPost(post:Post):Observable<Post>
   {
     return this.http.post<Post>(`${APIUrl}/post/create`, post);
   }

  UpdatePost(id:number, post:Post):Observable<Post>
  {
     return this.http.patch<Post>(`${APIUrl}/post/edit/${id}`, post);
  }

  DeletePost(id:number):Observable<any>
  {
    return this.http.delete(`${APIUrl}/post/delete/${id}`);
    console.log("Sukces!");
  }  
  }