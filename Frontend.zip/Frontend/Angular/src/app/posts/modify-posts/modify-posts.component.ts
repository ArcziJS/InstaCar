import { Component, OnInit } from '@angular/core';
import { response } from 'express';
import { SharedService } from 'src/app/shared.service';
import { Post } from '../../post.model'

@Component({
  selector: 'app-modify-posts',
  templateUrl: './modify-posts.component.html',
  styleUrls: ['./modify-posts.component.css']
})
export class ModifyPostsComponent implements OnInit
{
post = new Post();
poka=true;
      logowanie=false;
  constructor(private service: SharedService) { }

  ngOnInit(): void {
  }

  AddPost()
  {
    this.service.AddPost(this.post)
    .subscribe(response=>
      {
        console.log(response)
      })
  }

  EditPost()
  {
    this.service.UpdatePost(this.post.postId, this.post)
    .subscribe(response=>
      {
        console.log(response)
      })
  }

  DeletePost()
  {
    this.service.DeletePost(this.post.postId)
    .subscribe(response=>
      {
        console.log(response)
      })
  }
  


}
