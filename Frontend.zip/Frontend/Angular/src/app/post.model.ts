export class Post
{
postId: number = 0;
userId: number = 0;
postDescription: string = "";
creationDate: Date = new Date();
editionDate: Date= new Date();
likesCount: number = 0;
commentsCount: number = 0;
isActivePost: boolean = true;
isBannedPost: boolean = false;
}