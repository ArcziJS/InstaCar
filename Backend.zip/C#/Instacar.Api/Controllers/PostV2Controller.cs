﻿using System.Threading.Tasks;
using Instacar.Api.Mappers;
using Instacar.Api.Validation;
using Instacar.Data.Sql;
using Instacar.IServices.Post;
using Microsoft.AspNetCore.Mvc;

namespace Instacar.Api.Controllers
{
    [ApiVersion("2.0")]
    [Route("api/v{version:apiVersion}/Post")]
    public class PostV2Controller : Controller
    {
        private readonly InstacarDbContext _context;
        private readonly IPostService _PostService;

        /// <inheritdoc />
        public PostV2Controller(InstacarDbContext context, IPostService PostService)
        {
            _context = context;
            _PostService = PostService;
        }

        [HttpGet("{PostId:min(1)}", Name = "GetPostById")]
        public async Task<IActionResult> GetPostById(int PostId)
        {
            var Post = await _PostService.GetPostByPostId(PostId);
            if (Post != null)
            {
                return Ok(PostToPostViewModelMapper.PostToPostViewModel(Post));
            }
            return NotFound();
        }


        [ValidateModel]
        [HttpPost("create", Name = "CreatePost")]
        public async Task<IActionResult> Post([FromBody] IServices.Requests.CreatePost createPost)
        {
            var Post = await _PostService.CreatePost(createPost);

            return Created(Post.PostId.ToString(), PostToPostViewModelMapper.PostToPostViewModel(Post));
        }


        [ValidateModel]
        [HttpPatch("edit/{PostId:min(1)}", Name = "EditPost")]
        //        public async Task<IActionResult> EditPost([FromBody] EditPost editPost,[FromQuery] int PostId)
        public async Task<IActionResult> EditPost([FromBody] IServices.Requests.EditPost editPost, int PostId)
        {
            await _PostService.EditPost(editPost, PostId);

            return NoContent();
        }
        [ValidateModel]
        [HttpDelete("delete/{PostId:min(1)}", Name = "DeletePost")]
        public async Task<IActionResult> DeleteId([FromBody] IServices.Requests.DeletePost PostId)
        {
            await _PostService.DeletePost(PostId.PostId);

            return NoContent();
        }

    }
}