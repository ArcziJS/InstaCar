using System;
using System.Collections.Generic;

namespace Instacar.Data.Sql.DAO
{
    public class Post
    {
        public Post()
        {
            Comments = new List<Comment>();
            Multimedias = new List<Multimedia>();
            Tags = new List<Tag>();
        }
        
        public int PostId { get; set; }
        public int UserId { get; set; }
        public string PostDescription { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime EditionDate { get; set; }
        public int LikesCount { get; set; }
        public int CommentsCount { get; set; }
        public bool IsBannedPost { get; set; }
        public bool IsActivePost { get; set; }
        
        public virtual User User { get; set; }
        public virtual ICollection<Comment> Comments { get; set; }
        public virtual ICollection<Multimedia> Multimedias { get; set; }
        public virtual ICollection<Tag> Tags { get; set; }

    }
}