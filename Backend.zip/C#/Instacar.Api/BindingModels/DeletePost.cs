﻿using System.ComponentModel.DataAnnotations;

namespace Instacar.Api.BindingModels
{
    public class DeletePost
    {
        [Required]
        [Display(Name = "PostId")]
        public int PostId { get; set; }
    }
}
