namespace Instacar.Common.Enums
{
    public enum MediaType
    {
        Image = 0,
        Video = 1

    }
}