﻿using System;
using System.Threading.Tasks;
using Instacar.Common.Enums;
using Instacar.Domain.DomainExceptions;
using Instacar.IData.Post;
using Instacar.IServices.Requests;
using Instacar.IServices.Post;
using Instacar.Services.Post;
using Moq;
using Xunit;

namespace Instacar.Services.Tests.Post
{
    public class PostServiceTest
    {
        private readonly IPostService _PostService;
        private readonly Mock<IPostRepository> _PostRepositoryMock;

        public PostServiceTest()
        {
            //Arrange
            _PostRepositoryMock = new Mock<IPostRepository>();
            _PostService = new PostService(_PostRepositoryMock.Object);
        }

        [Fact]
        public async Task CreatePost_Returns_Correct_Response()
        {
            var Post = new CreatePost
            {
                UserId = 1,
                PostDescription = "Opis",
                CreationDate = DateTime.UtcNow,
                EditionDate = DateTime.UtcNow,
            };

            int expectedResult = 0;
            _PostRepositoryMock.Setup(x => x.AddPost
                (new Domain.Post.Post
                (Post.UserId,
                    Post.PostDescription,
                    Post.CreationDate,
                    Post.EditionDate)))
                .Returns(Task.FromResult(expectedResult));

            //Act
            var result = await _PostService.CreatePost(Post);

            //Assert
            Assert.IsType<Domain.Post.Post>(result);
            Assert.NotNull(result);
            Assert.Equal(expectedResult, result.PostId);
        }

    }
}