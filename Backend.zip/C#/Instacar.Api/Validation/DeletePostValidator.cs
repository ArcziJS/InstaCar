﻿using FluentValidation;
using Instacar.Api.BindingModels;

namespace Instacar.Api.Validation
{
    public class DeletePostValidator : AbstractValidator<DeletePost>
    {
        public DeletePostValidator()
        {
            RuleFor(x => x.PostId).NotNull();
        }
    }

}