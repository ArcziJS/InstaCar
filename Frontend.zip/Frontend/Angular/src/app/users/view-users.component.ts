import { Component, OnInit } from '@angular/core';
import { User } from '../user.model'
import { SharedService } from 'src/app/shared.service';
import { response } from 'express';

@Component({
    selector: 'app-view-users',
    template: ''
  })

export class ViewUsersComponent implements OnInit
{

    constructor(public service: SharedService) { }
    user:User = new User();

    ngOnInit(): void {

    }

    GetUser(id: number)
    {
        this.service.GetUser(id).subscribe(response => {
            this.user = response;})
    }
}