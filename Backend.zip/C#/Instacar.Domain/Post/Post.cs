﻿using System;
using System.Collections.Generic;
using Instacar.Domain.DomainExceptions;

namespace Instacar.Domain.Post
{
	public class Post
	{
		public int PostId { get; set; }
		public int UserId { get; set; }
		public string PostDescription { get; set; }
		public DateTime CreationDate { get; set; }
		public DateTime EditionDate { get; set; }
		public int LikesCount { get; set; }
		public int CommentsCount { get; set; }
		public bool IsBannedPost { get; set; }
		public bool IsActivePost { get; set; }

		public Post(int postId, int userId, string postDescription, DateTime creationDate, DateTime editionDate, int likesCount, int commentsCount, bool isBannedPost, bool isActivePost)
		{
			PostId = postId;
			UserId = userId;  
			PostDescription = postDescription;
			CreationDate = creationDate;
			EditionDate = editionDate;   
			LikesCount = likesCount;
			CommentsCount = commentsCount;
			IsBannedPost = isBannedPost;
			IsActivePost= isActivePost;
		}

		public Post(int userId, string postDescription, DateTime creationDate, DateTime editionDate)
		{
			UserId = userId;
			PostDescription = postDescription;
			CreationDate = creationDate;
			EditionDate = editionDate;
		}

		public void EditPost(int postId, string postDescription, DateTime datetime)
        {
			PostId = postId;
			PostDescription=postDescription;
			EditionDate = datetime;
        }

		public void DeletePost(int postId)
        {
			PostId=postId;
        }

	}
}