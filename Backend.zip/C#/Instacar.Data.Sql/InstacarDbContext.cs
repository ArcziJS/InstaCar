﻿using Instacar.Data.Sql.DAO;
using Instacar.Data.Sql.DAOConfigurations;
using Microsoft.EntityFrameworkCore;

namespace Instacar.Data.Sql
{ 
    public class InstacarDbContext : DbContext
    {
        public InstacarDbContext(DbContextOptions<InstacarDbContext> options) : base(options) { }
      
        public virtual DbSet<Comment> Comment { get; set; }
        public virtual DbSet<Multimedia> Multimedia { get; set; }
        public virtual DbSet<DAO.Post> Post { get; set; }
        public virtual DbSet<Tag> Tag { get; set; }
        public virtual DbSet<DAO.User> User { get; set; }

        //Przykład konfiguracji modeli/encji poprzez klasy konfiguracyjne z folderu DAOConfigurations
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfiguration(new CommentConfiguration());
            builder.ApplyConfiguration(new MediaConfiguration());
            builder.ApplyConfiguration(new PostConfiguration());
            builder.ApplyConfiguration(new TagConfiguration());
            builder.ApplyConfiguration(new UserConfiguration());
        }
    }
}