using Instacar.Common.Enums;

namespace Instacar.Data.Sql.DAO
{
    public class Multimedia
    {
        public int MultimediaId { get; set; }
        public int PostId { get; set; }
        public MediaType MediaType { get; set; }
        public string MultimediaHref { get; set; }
        public int Order { get; set; }
        
        public virtual Post Post { get; set; }

    }
}