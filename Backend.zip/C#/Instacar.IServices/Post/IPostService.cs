﻿using System.Threading.Tasks;
using Instacar.IServices.Requests;

namespace Instacar.IServices.Post
{
    public interface IPostService
    {
        Task<Instacar.Domain.Post.Post> GetPostByPostId(int PostId);
        Task<Instacar.Domain.Post.Post> CreatePost(CreatePost createPost);
        Task<Instacar.Domain.Post.Post> EditPost(EditPost editPost, int PostId);
        Task<Instacar.Domain.Post.Post> DeletePost(int PostId);
    }
}