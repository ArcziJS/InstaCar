using System.Collections.Generic;

namespace Instacar.Data.Sql.DAO
{
    public class Tag
    {
        
        public int TagId { get; set; }
        public string TagName { get; set; }
        

    }
}