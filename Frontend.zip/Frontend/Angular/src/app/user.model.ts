export class User
{
    userId:number = 1;
    userName: string = "";
    email: string = "";
    registrationsDate: Date=new Date();
    editionDate: Date=new Date();
    userInfoEditionDate: Date=new Date();
    gender: number=0;
    birthDate: Date=new Date();
    isBannedUser: boolean=false;
    isActiveUser: boolean=true;
    postCount: number=0;
    followersCount: number=0;
    followingCount: number=0;
    accountDescription: string="";
    accountPrivateHref: string="";
    iconHref: string="";
    thumbnailHref: string="";


}