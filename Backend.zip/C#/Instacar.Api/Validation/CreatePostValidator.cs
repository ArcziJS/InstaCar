﻿using FluentValidation;
using Instacar.Api.BindingModels;

namespace Instacar.Api.Validation
{
    public class CreatePostValidator : AbstractValidator<CreatePost>
    {
        public CreatePostValidator()
        {
            RuleFor(x => x.UserId).NotNull();
            RuleFor(x => x.PostDescription).NotNull();
            RuleFor(x => x.CreationDate).NotNull();
            RuleFor(x => x.EditionDate).NotNull();
        }
    }

}