﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Instacar.IServices.Requests
{
    public class CreatePost
    {
        [Required]
        [Display(Name = "UserId")]
        public int UserId { get; set; }

        [Required]
        [Display(Name = "PostDescription")]
        public string PostDescription { get; set; }

        [Required]
        [Display(Name = "CreationDate")]
        public DateTime CreationDate { get; set; }

        [Required]
        [Display(Name = "EditionDate")]
        public DateTime EditionDate { get; set; }

    }
}
