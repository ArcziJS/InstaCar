﻿using System.Threading.Tasks;
using Instacar.IData.Post;
using Instacar.IServices.Requests;
using Instacar.IServices.Post;

namespace Instacar.Services.Post
{
    public class PostService : IPostService
    {
        private readonly IPostRepository _PostRepository;

        public PostService(IPostRepository PostRepository)
        {
            _PostRepository = PostRepository;
        }

        public Task<Domain.Post.Post> GetPostByPostId(int PostId)
        {
            return _PostRepository.GetPost(PostId);
        }

        public async Task<Domain.Post.Post> CreatePost(CreatePost createPost)
        {
            var Post = new Domain.Post.Post(createPost.UserId, createPost.PostDescription, createPost.CreationDate, createPost.EditionDate);
            Post.PostId = await _PostRepository.AddPost(Post);
            return Post;
        }

        public async Task<Domain.Post.Post> EditPost(EditPost editPost, int PostId)
        {
            var Post = await _PostRepository.GetPost(PostId);
            Post.EditPost(editPost.PostId, editPost.PostDescription, editPost.EditionDate);
            await _PostRepository.EditPost(Post);
            return Post;
        }

        public async Task<Domain.Post.Post> DeletePost(int PostId)
        {
            var Post = await _PostRepository.GetPost(PostId);
            await _PostRepository.DeletePost(Post);
            return Post;
        }
    }

}