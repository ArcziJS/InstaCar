namespace Instacar.Common.Enums
{
    public enum Gender
    {
        Male = 0,
        Female = 1

    }
}