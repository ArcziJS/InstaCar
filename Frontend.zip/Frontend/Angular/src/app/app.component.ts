import { Component, OnInit } from '@angular/core';
import { SharedService } from './shared.service';
import { Post } from './post.model'
import { response } from 'express';
import { NgForm } from '@angular/forms';
import { User } from './user.model'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  user:User=new User();
  newpost:Post=new Post();
  post:Post=new Post();
  title: string = "Insta Car"
  i:number = 1;
  poka: boolean=false;
  logowanie: boolean=true;
  constructor(public service:SharedService) {}
  

  ngOnInit() {
    this.GetPost(this.i)
  }
  GetPost(id: number)
  {
    this.service.GetPost(id)
        .subscribe(response => {
          this.post = response;
          this.GetUserName(this.post.userId);
          console.log(this.post)
        });
  }

  DeletePost(id: number)
  {
    this.service.DeletePost(id).subscribe(response => {
      console.log(response)});
      this.GetPost(++this.i);
      this.poka=true;
      this.logowanie=false;
  }

  EditPost(id:number, edytowany:Post)
  {
    this.service.UpdatePost(id,edytowany).subscribe(response => {
      console.log(response)});
      alert('Udało się.')
      this.GetPost(id);
      this.poka=true;
      this.logowanie=false;
      this.GetPost(id);
  }

  DajLajka(id:number, polubiony:Post)
  {
    polubiony.likesCount++;
    console.log(polubiony);
    this.service.UpdatePost(id,polubiony).subscribe(response => {
      console.log(response)});
      alert("Polubiono.")
      this.GetPost(id);
      this.poka=true;
      this.logowanie=false;
  }

  AddPost(newPost:Post)
  {
    console.log(newPost);
    this.service.AddPost(newPost).subscribe(response=>
      {
        console.log(response);
      })
      alert("Dodano.")
      this.poka=true;
      this.logowanie=false;
  }

  GetUserName(id:number)
{
  this.service.GetUser(id).subscribe(response=>
    {
      this.user=response;
      console.log(this.user);
    })
}

GetUser(name:string)
{
  alert("Witaj! "+name);
  this.service.GetUserName(name).subscribe(response=>
    {
      this.user=response;
      console.log(this.user);
      this.poka=true;
      this.logowanie=false;
      this.ngOnInit();
    })
}
}