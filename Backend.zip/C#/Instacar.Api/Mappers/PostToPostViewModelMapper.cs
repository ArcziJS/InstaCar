﻿using Instacar.Api.ViewModels;

namespace Instacar.Api.Mappers
{
    public class PostToPostViewModelMapper
    {
        public static PostViewModel PostToPostViewModel(Domain.Post.Post post)
        {
            var PostViewModel = new PostViewModel
            {
                PostId = post.PostId,
                UserId = post.UserId,
                PostDescription = post.PostDescription,
                CreationDate = post.CreationDate,
                EditionDate = post.EditionDate,
                LikesCount = post.LikesCount,
                CommentsCount = post.CommentsCount,
                IsBannedPost = post.IsBannedPost,
                IsActivePost = post.IsActivePost
            };
            return PostViewModel;
        }

    }
}
